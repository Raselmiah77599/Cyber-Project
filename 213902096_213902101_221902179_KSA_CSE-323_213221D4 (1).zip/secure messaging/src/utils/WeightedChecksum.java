package src.utils;

// work in ASCII value level
public class WeightedChecksum {
    // generate weighted checksum based on ASCII Value
    public static int generateChecksum(String text) {
        int checksum = 0;
        int weight = 1;
        for (char c : text.toCharArray()) {
            checksum += c * weight;
            weight++;
        }
        checksum %= 256;
        return checksum;
    }

    // verify checksum
    public static boolean verifyChecksum(String text, int providedChecksum) {
        int calculatedChecksum = generateChecksum(text);
        return calculatedChecksum == providedChecksum;
    }

//    public static void main(String[] args) {
//
//        String message = "masud";
//        int checksum = generateChecksum(message);
//        System.out.println("Original Message: " + message);
//        System.out.println("Generated Checksum: " + checksum);
//
//        // Simulate receiver verifying the checksum
//        boolean isValid = verifyChecksum(message, checksum);
//        System.out.println("Is message valid? " + isValid);
//    }
}
