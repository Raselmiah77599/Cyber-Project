//package src.utils;
//
//public class BinaryChecksum {
//
//    // calculate checksum and working binary bits level
//    public static String calculateChecksum(String[] message) {
//        int sum = 0;
//
//        // Add all binary chunks
//        for (String chunk : message) {
//            sum += Integer.parseInt(chunk, 2);
//
//            if (sum > 0xFF) {
//                sum = (sum & 0xFF) + 1;
//            }
//        }
//
//        //1's complement of the sum
//        int checksum = ~sum & 0xFF;
//
//        // return the check as binary bits
//        return String.format("%8s", Integer.toBinaryString(checksum)).replace(' ', '0');
//    }
//
//    // verify checksum value with message
//    public static boolean verifyChecksum(String[] message, String checksum) {
//        int sum = 0;
//        for (String chunk : message) {
//            sum += Integer.parseInt(chunk, 2);
//
//            if (sum > 0xFF) {
//                sum = (sum & 0xFF) + 1;
//            }
//        }
//
//        // add checksum value with the original message
//        sum += Integer.parseInt(checksum, 2);
//
//        // handle overflow carry bit
//        if (sum > 0xFF) {
//            sum = (sum & 0xFF) + 1;
//        }
//
//        // return True if passing checksum and current checksum is all zeros in both sides. else return False
//        return (~sum & 0xFF) == 0x00;
//    }
//
//    public static void main(String[] args) {
//        // Example data
//        String[] data = {"10101001", "00111001", "10100010"};
//
//        // Calculate checksum at sender site
//        String checksum = calculateChecksum(data);
//        System.out.println("Calculated Checksum: " + checksum);
//
//        // Transmit data and checksum
//        System.out.println("Data transmitted: ");
//        for (String chunk : data) {
//            System.out.println(chunk);
//        }
//        System.out.println("Checksum transmitted: " + checksum);
//
//        // Verify checksum at receiver site
//        boolean isValid = verifyChecksum(data, checksum);
//        System.out.println("Is data valid? " + (isValid ? "Yes" : "No"));
//    }
//}
//
//



package src.utils;

public class BinaryChecksum {

    // calculate checksum and working binary bits level
    public static String calculateChecksum(String message) {
        int sum = 0;

        // Add all binary chunks
        for (char chunk : message.toCharArray()) {
            sum += chunk;

            if (sum > 0xFF) {
                sum = (sum & 0xFF) + 1;
            }
        }

        //1's complement of the sum
        int checksum = ~sum & 0xFF;

        // return the check as binary bits
        return String.format("%8s", Integer.toBinaryString(checksum)).replace(' ', '0');
    }

    // verify checksum value with message
    public static boolean verifyChecksum(String message, String checksum) {
        int sum = 0;
        for (char chunk : message.toCharArray()) {
            sum += chunk;

            if (sum > 0xFF) {
                sum = (sum & 0xFF) + 1;
            }
        }

        // add checksum value with the original message
        sum += Integer.parseInt(checksum, 2);

        // handle overflow carry bit
        if (sum > 0xFF) {
            sum = (sum & 0xFF) + 1;
        }

        // return True if passing checksum and current checksum is all zeros in both sides. else return False
        return (~sum & 0xFF) == 0x00;
    }
//
//    public static void main(String[] args) {
//        // Example data
//        String data = "masud";
//
//        // Calculate checksum at sender site
//        String checksum = calculateChecksum(data);
//        System.out.println("Calculated Checksum: " + checksum);
//
//        // Transmit data and checksum
//        System.out.println("Data transmitted: ");
//        for (char chunk : data.toCharArray()) {
//            System.out.println(chunk);
//        }
//        System.out.println("Checksum transmitted: " + checksum);
//
//        // Verify checksum at receiver site
//        boolean isValid = verifyChecksum(data, checksum);
//        System.out.println("Is data valid? " + (isValid ? "Yes" : "No"));
//    }
}
